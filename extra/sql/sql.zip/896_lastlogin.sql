ALTER TABLE `players` ADD `lastlogin` INT( 11 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `guild_rank` 
