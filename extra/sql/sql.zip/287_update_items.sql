UPDATE item_attributes SET `key`='turns' WHERE `key`='count';
