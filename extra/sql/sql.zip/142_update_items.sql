UPDATE item_attributes SET `key`='floorChange' WHERE `key` LIKE 'floorchange';
UPDATE item_attributes SET `key`='fluidSource' WHERE `key` LIKE 'fluidSource';