UPDATE `item_attributes` SET `key` = 'defense' WHERE `key` = 'extradef';
UPDATE `item_attributes` SET `key` = 'defence' WHERE `key` = 'defense';
